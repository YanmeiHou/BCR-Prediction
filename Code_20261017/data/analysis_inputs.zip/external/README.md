# External inputs

- `discovery/`: TCGA-PRAD_eSet.RDS, PCaDB_Gene_Annotation.RDS.
- `modelling/`: the four original cohort ExpressionSets, as required by historical ML.
- `bulk/`: TCGA-PRAD_eSet.RDS, DKFZ_eSet.RDS, Taylor_eSet.RDS, CancerMap_eSet.RDS.
- `CIBERSORT/`: legitimately obtained CIBERSORT.R and LM22.txt.
- Matching Hallmark GMT for historical GSEA.
- `drug/DataFiles/Training Data/`: GDSC2 expression/response objects for optional oncoPredict.
- `single_cell/`: real count matrices, cell metadata and cluster annotations. `.example.csv` files are schemas only.
- `final_predictions.csv`: reviewed per-patient predictions for optional AUC uncertainty analysis.

Derived small inputs under `data/derived/` support the documented reproduction routes without these large resources.
Do not substitute synthetic inputs or infer missing annotations automatically.
